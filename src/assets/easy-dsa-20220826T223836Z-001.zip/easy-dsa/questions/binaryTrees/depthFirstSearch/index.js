/** Depth First Search **
 * 
 * Return the depth first values of the given binary tree in 
 * an array.  
 * 
 */

 const depthFirstSearch = (root) => {

}


module.exports = depthFirstSearch;