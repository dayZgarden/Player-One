/** Remove Nth Node from End of Linked List  **
 * 
 * Given an integer n, remove the nth node of the linked list 
 * from the end. 
 *  
 * @example
 * removeNthFromEnd(1 -> 2 -> 3, 2) 1 -> 3
 * removeNthFromEnd(10 -> 20 -> 30 -> 40, 1) 10 -> 20 -> 30
 * removeNthFromEnd(100 -> 200 -> 300 -> 400 -> 500, 2) 100 -> 200 -> 300 -> 500
 * 
 */

 const removeNthFromEnd = (head, n) => {

}











//DO NOT EDIT BELOW THIS LINE
class Node{
  constructor (val, next){
    this.val = val
    this.next = next
  }
}

module.exports = removeNthFromEnd;