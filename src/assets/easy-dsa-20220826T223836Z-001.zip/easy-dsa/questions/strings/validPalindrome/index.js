/** Valid Palindrome **
 * 
 * Given a string, determine if it is a valid palindrome or not.
 * Ignore all spaces, non-alphanumeric characters and capitalisation of letters. 
 *  
 * @example
 * validPalindrome("racecar") -> true
 * validPalindrome("r A C ec  ar") -> true
 * validPalindrome("I like to code.") -> false 
 * 
 */

 const validPalindrome = (str) => {

}

module.exports = validPalindrome;